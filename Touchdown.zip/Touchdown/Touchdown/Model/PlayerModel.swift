//
//  Created by Hüseyin Cem Ayaz

import Foundation

struct Player: Codable, Identifiable {
  let id: Int
  let image: String
}
